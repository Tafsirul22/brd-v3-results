"""External tool integrations package."""
