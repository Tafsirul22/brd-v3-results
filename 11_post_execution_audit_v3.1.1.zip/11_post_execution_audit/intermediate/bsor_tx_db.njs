{
  "version": "1.2",
  "dbname": "bsor_tx_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "C:\\Users\\ASUSBA~1\\Desktop\\NEWFOL~2\\Output\\03_ANN~1\\TRANSC~1\\GENOME~1.FAS",
  "number-of-letters": 18912434,
  "number-of-sequences": 12210,
  "last-updated": "2026-11-11T10:01:00",
  "number-of-volumes": 1,
  "bytes-total": 8038993,
  "bytes-to-cache": 4882389,
  "files": [
    "bsor_tx_db.ndb",
    "bsor_tx_db.nhr",
    "bsor_tx_db.nin",
    "bsor_tx_db.not",
    "bsor_tx_db.nsq",
    "bsor_tx_db.ntf",
    "bsor_tx_db.nto"
  ]
}
